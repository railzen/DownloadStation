# Cherry一键脚本工具

## 介绍
Cherry脚本工具是一款全能脚本工具箱，专为 VPS 监控、测试和管理而设计。无论您是初学者还是经验丰富的用户，该工具都能为您提供便捷的解决方案。整合了各类系统工具面板的安装及使用，加入了修改过的搭建服务脚本，使系统维护变得更加简单。作为一个实用工具，力求在便捷性和安全性上取得平衡。




## 使用方法
### Debian / Ubuntu 安装下载工具
```bash
apt update -y  && apt install -y curl
```
### CentOS 安装下载工具
```bash
apt update -y  && apt install -y curl
```
***
### 一键脚本
```bash
curl -sS -O https://raw.githubusercontent.com/railzen/DownloadStation/main/Shell/cherry/ludo.sh && chmod +x ludo.sh && ./ludo.sh
```

